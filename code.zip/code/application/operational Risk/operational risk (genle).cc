#ifndef CDECL
#ifdef _WIN32
#define CDECL __cdecl
#else
#define CDECL
#endif
#endif
#define SMILE_NO_V1_COMPATIBILITY
#include <vector>
#include <string>
#include <iostream>
#include <smile.h>
#include <node.h>
#include <cstdio>
#include <discdef.h>
#include <nodedef.h>
#include <nodeval.h>
#include <network.h>
#include <iomanip>
#include "progress.h"
#include "smile_license.h"

struct TsTriangulatorStats
{
	unsigned nodeCount;
	unsigned threshold;
	unsigned cliqueCount;
	unsigned totalCliqueSize;
	unsigned maxCliqueSize;
	unsigned maxCliqueWidth;
	unsigned totalSeparatorSize;
	unsigned maxSeparatorSize;
	unsigned maxSeparatorWidth;
	std::vector<unsigned> cliqueSizes;
};
extern void (CDECL* TsTriangulatorStatsFunc)(TsTriangulatorStats*);


class MyProgress : public DSL_progress {
public:
    virtual bool Tick(double percComplete, const char *msg) override {
        if (percComplete >= 0) {
            std::cout << "Progress: " << std::fixed << std::setprecision(2) << percComplete << "% completed.";
        } else {
            std::cout << "Progress: Unable to estimate completion percentage.";
        }

        if (msg) {
            std::cout << " Message: " << msg;
        }
        std::cout << std::endl;

        return true; 
    }
};

static int CreateCptNode(DSL_network &net, const char *id, const char *name, std::initializer_list<const char *> outcomes, int xPos, int yPos);
static void ShowStats(DSL_network &net, int nodeHandle);
static void UpdateAndShowStats(DSL_network &net);
static int CreateEquationNode(
	DSL_network &net, const char *id, const char *name,
    const char *equation, double loBound, double hiBound,
    int xPos, int yPos);
static void PrintPosteriors(DSL_network &net, int handle);
static void PrintAllPosteriors(DSL_network &net);
static void SetUniformIntervals(DSL_network &net, int nodeHandle, int count);
static int ChangeEvidenceAndUpdate(
    DSL_network &net, const char *nodeId, const char *outcomeId);
static void PrintMatrix(
    DSL_network &net, const DSL_Dmatrix &mtx, 
    const DSL_idArray &outcomes, const DSL_intArray &parents);
static void PrintNodeInfo(DSL_network &net, int nodeHandle);
static int CopyNode(DSL_network &net, int sourceNodeHandle, const std::string &newNodeId, int start, int end);
static std::vector<std::string> CreateTn(DSL_network &net, const std::string &baseNameS, const std::string &baseNameT, 
                                                 double loBound, double hiBound, int xPos, int yPos, int discIntervals, int numSNodes,int numNodes,const std::string &equation);
static std::vector<int> CreateFNodes(DSL_network &net, const std::string &baseName,
                                     int fHandle, const std::vector<std::string> &tNodeIds,
                                     int xPos, int yPos, int discIntervals,
                                     double loBound, double hiBound, int s);
std::string join(const std::vector<std::string>& elements, const std::string& separator);
void CheckIfNodeIsDiscretized(DSL_network &net, int nodeHandle) {
    DSL_node *node = net.GetNode(nodeHandle);
    if (!node) {
        std::cerr << "The node is invalid or does not exist." << std::endl;
        return;
    }

    // Obtain the equation evaluation object of the node
    auto eqVal = node->Val<DSL_equationEvaluation>();
    
    // Check if it has been discretized
    if (eqVal->IsDiscretized()) {
        std::cout << "node " << node->GetId() << " has been discretized" << std::endl;
    } else {
        std::cout << "node " << node->GetId() << " has not been discretized" << std::endl;
    }
}

void CDECL MyTriangulatorStatsFunc(TsTriangulatorStats* stats)
{
    printf("maxCliqueSize=%d, totalCliqueSize=%d, maxCliqueWidth=%d, nodeCount=%d, cliqueCount=%d, totalSeparatorSize=%d\n", stats->maxCliqueSize, stats->totalCliqueSize, stats->maxCliqueWidth, stats->nodeCount, stats->cliqueCount, stats->totalSeparatorSize);
    fflush(stdout);  
}


int main()
{
    DSL_errorH().RedirectToFile(stdout);
    DSL_network net;
    int discIntervals = 35; 
    int t = 70;
    MyProgress progress;
    int io = 0;
    int resultCode = net.SetNumberOfSamples(10000);
    if (resultCode != DSL_OKAY) {
        std::cerr << "Failed to set the number of samples. Error code: " << resultCode << std::endl;
    }
    net.SetNumberOfDiscretizationSamples(1000);
    net.EnableRejectOutlierSamples(true);
    TsTriangulatorStatsFunc = &MyTriangulatorStatsFunc;

    // operational proc.quality
    int OHandle = CreateCptNode(net, "O", "operational proc.quality", {"O1", "O2","O3", "O4","O5"}, 0, -200);
    // cpt
    int res4 = net.GetNode(OHandle)->Def()->SetDefinition({
        0.07142857142857142,
        0.07142857142857142,
        0.4285714285714285,
        0.2857142857142857,
        0.1428571428571429
    });
    if (DSL_OKAY != res4)
    {
        std::cerr << "Failed to set definition.\n";
        return res4;
    }

    int TFHandle = CreateCptNode(net, "TF", "technology fidelity", {"TF1", "TF2", "TF3", "TF4", "TF5"}, 200, -200);
    // cpt
    int res5 = net.GetNode(TFHandle)->Def()->SetDefinition({
        0.2666666666666667,
        0.06666666666666667,
        0.4,
        0.1333333333333333,
        0.1333333333333333
    });
    if (DSL_OKAY != res5)
    {
        std::cerr << "Failed to set definition.\n";
        return res5;
    }

    int QHandle = CreateCptNode(net, "Q", "staff quality", {"Q1", "Q2", "Q3", "Q4", "Q5"}, 400, -200);
    // cpt
    int res6 = net.GetNode(QHandle)->Def()->SetDefinition({
        0.04761904761904762,
        0.1904761904761905,
        0.2857142857142857,
        0.3809523809523809,
        0.09523809523809534
    });
    if (DSL_OKAY != res6)
    {
        std::cerr << "Failed to set definition.\n";
        return res6;
    }

    int EHandle = CreateCptNode(net, "E", "process effectiveness", {"E1", "E2", "E3", "E4", "E5", "E6", "E7"}, 200, -50);
    net.AddArc(OHandle, EHandle);
    net.AddArc(TFHandle, EHandle);
    net.AddArc(QHandle, EHandle);
    // cpt
    int res7 = net.GetNode(EHandle)->Def()->SetDefinition({ 0.046977422, 0.001092498, 0.000728332, 0.750546249, 0.187909687, 0.000728332, 0.01201748, 0.231693364, 0.00228833, 0.00228833, 0.010297483, 0.751716247, 0.001144165, 0.000572082, 0.096288867, 0.000401204, 0.750150451, 0.000200602, 0.128184554, 0.024373119, 0.000401204, 0.438829787, 0.015957447, 0.015957447, 0.013297872, 0.505319149, 0.005319149, 0.005319149, 0.102564103, 0.002849003, 0.0, 0.760683761, 0.128205128, 0.002849003, 0.002849003, 0.012195122, 0.756097561, 0.012195122, 0.170731707, 0.044715447, 0.004065041, 0.0, 0.014084507, 0.014084507, 0.014084507, 0.169014085, 0.76056338, 0.014084507, 0.014084507, 0.000194, 0.0, 0.016880093, 0.782887078, 0.196, 0.000776, 0.003104385, 0.019230769, 0.009615385, 0.75, 0.179487179, 0.012820513, 0.012820513, 0.016025641, 0.017647059, 0.0, 0.035294118, 0.9, 0.023529412, 0.0, 0.023529412, 0.009259259, 0.005555556, 0.194444444, 0.033333333, 0.001851852, 0.005555556, 0.75, 0.000551572, 0.750137893, 0.00551572, 0.0, 0.242691671, 0.000551572, 0.000551572, 0.017751479, 0.00887574, 0.195266272, 0.00295858, 0.75443787, 0.00295858, 0.017751479, 0.015974441, 0.012779553, 0.003194888, 0.191693291, 0.0, 0.019169329, 0.757188498, 0.005381166, 0.750672646, 0.004484305, 0.11838565, 0.11838565, 0.001793722, 0.000896861, 0.0, 0.181818182, 0.090909091, 0.0, 0.181818182, 0.272727273, 0.272727273, 0.065789474, 0.0, 0.0, 0.0, 0.0, 0.907894737, 0.026315789, 0.005319149, 0.021276596, 0.015957447, 0.031914894, 0.75, 0.170212766, 0.005319149, 0.00617284, 0.008230453, 0.010288066, 0.002057613, 0.012345679, 0.907407407, 0.053497942, 0.022727273, 0.011363636, 0.011363636, 0.015151515, 0.007575758, 0.909090909, 0.022727273, 0.03125, 0.0, 0.75, 0.03125, 0.0, 0.1875, 0.0, 0.175824176, 0.021978022, 0.758241758, 0.010989011, 0.021978022, 0.0, 0.010989011, 0.006465517, 0.756465517, 0.172413793, 0.047413793, 0.002155172, 0.002155172, 0.012931034, 0.045977011, 0.712643678, 0.068965517, 0.011494253, 0.045977011, 0.045977011, 0.068965517, 0.005964215, 0.206759443, 0.003976143, 0.003976143, 0.011928429, 0.757455268, 0.009940358, 0.005586592, 0.0, 0.0, 0.016759777, 0.754189944, 0.033519553, 0.189944134, 0.008130081, 0.024390244, 0.008130081, 0.504065041, 0.008130081, 0.089430894, 0.357723577, 2.24e-05, 7.47e-06, 0.028577828, 0.971153415, 7.47e-06, 2.24e-05, 0.000209033, 0.011473153, 0.751720973, 0.000917852, 0.189995411, 0.000917852, 0.000917852, 0.044056907, 0.151515152, 0.090909091, 0.060606061, 0.0, 0.03030303, 0.0, 0.666666667, 0.0, 0.763636364, 0.181818182, 0.018181818, 0.0, 0.018181818, 0.018181818, 0.017804154, 0.014836795, 0.178041543, 0.008902077, 0.756676558, 0.014836795, 0.008902077, 0.022058824, 0.0, 0.176470588, 0.022058824, 0.018382353, 0.761029412, 0.0, 0.024390244, 0.073170732, 0.682926829, 0.073170732, 0.024390244, 0.048780488, 0.073170732, 0.002364066, 0.002364066, 0.226950355, 0.002364066, 0.011820331, 0.75177305, 0.002364066, 0.044560944, 0.001310616, 0.001310616, 0.75491481, 0.005242464, 0.0, 0.19266055, 0.008050089, 0.000894454, 0.008050089, 0.058363148, 0.923076923, 0.000894454, 0.000670841, 0.0, 0.0, 0.015228426, 0.010152284, 0.944162437, 0.015228426, 0.015228426, 0.002095627, 0.0, 0.00027574, 0.01687531, 0.977885623, 5.51e-05, 0.002812552, 0.173913043, 0.043478261, 0.260869565, 0.043478261, 0.217391304, 0.130434783, 0.130434783, 0.178861789, 0.008130081, 0.780487805, 0.008130081, 0.008130081, 0.008130081, 0.008130081, 0.013377926, 0.200668896, 0.752508361, 0.0, 0.006688963, 0.016722408, 0.010033445, 0.091954023, 0.003284072, 0.009852217, 0.004926108, 0.873563218, 0.006568144, 0.009852217, 0.003846154, 0.002564103, 0.973076923, 0.003846154, 0.003846154, 0.007692308, 0.005128205, 0.006543075, 0.971646674, 0.005452563, 0.00436205, 0.00436205, 0.00436205, 0.003271538, 0.055555556, 0.018518519, 0.777777778, 0.037037037, 0.0, 0.111111111, 0.0, 0.095238095, 0.19047619, 0.19047619, 0.095238095, 0.047619048, 0.095238095, 0.285714286, 0.0, 0.105263158, 0.263157895, 0.263157895, 0.105263158, 0.105263158, 0.157894737, 0.054945055, 0.010989011, 0.043956044, 0.065934066, 0.758241758, 0.0, 0.065934066, 0.16, 0.08, 0.08, 0.24, 0.24, 0.16, 0.04, 0.005025126, 0.005025126, 0.002512563, 0.472361809, 0.002512563, 0.012562814, 0.5, 0.000832224, 0.0, 0.997669774, 0.000166445, 0.000665779, 0.0, 0.000665779, 0.105263158, 0.0, 0.157894737, 0.263157895, 0.052631579, 0.263157895, 0.157894737, 0.013377926, 0.190635452, 0.003344482, 0.006688963, 0.762541806, 0.003344482, 0.02006689, 0.0, 0.285714286, 0.19047619, 0.19047619, 0.0, 0.142857143, 0.19047619, 0.005319149, 0.159574468, 0.0, 0.008865248, 0.808510638, 0.010638298, 0.007092199, 0.0, 0.017391304, 0.004347826, 0.02173913, 0.195652174, 0.756521739, 0.004347826, 0.033557047, 0.033557047, 0.020134228, 0.006711409, 0.832214765, 0.040268456, 0.033557047, 0.230769231, 0.192307692, 0.192307692, 0.0, 0.230769231, 0.115, 0.038461538, 0.024390244, 0.0, 0.024390244, 0.036585366, 0.073170732, 0.036585366, 0.804878049, 0.0, 0.004424779, 0.004424779, 0.199115044, 0.008849558, 0.026548673, 0.756637168, 0.002123142, 0.152866242, 0.806794055, 0.006369427, 0.006369427, 0.012738854, 0.012738854, 0.045801527, 0.778625954, 0.038167939, 0.045801527, 0.030534351, 0.030534351, 0.030534351, 0.011560694, 0.007707129, 0.007707129, 0.005780347, 0.001926782, 0.809248555, 0.156069364, 0.003080082, 0.18788501, 0.0, 0.804928131, 0.002053388, 0.001026694, 0.001026694, 0.0, 0.0, 0.188461538, 0.005128205, 0.805128205, 0.0, 0.001282051, 0.003030303, 0.003030303, 0.8, 0.163636364, 0.009090909, 0.003030303, 0.018181818, 0.084745763, 0.762711864, 0.0, 0.016949153, 0.084745763, 0.050847458, 0.0, 0.0, 0.051282051, 0.012820513, 0.051282051, 0.807692308, 0.012820513, 0.064102564, 0.125, 0.0625, 0.25, 0.0625, 0.25, 0.1875, 0.0625, 0.047169811, 0.018867925, 0.037735849, 0.009433962, 0.830188679, 0.037735849, 0.018867925, 0.01010101, 0.01010101, 0.151515152, 0.808080808, 0.005050505, 0.01010101, 0.005050505, 0.037735849, 0.056603774, 0.018867925, 0.037735849, 0.018867925, 0.830188679, 0.0, 0.041666667, 0.208333333, 0.125, 0.083333333, 0.125, 0.166666667, 0.25, 0.005208333, 0.008680556, 0.006944444, 0.805555556, 0.010416667, 0.15625, 0.006944444, 0.010526316, 0.021052632, 0.052631579, 0.789473684, 0.042105263, 0.052631579, 0.031578947, 0.009009009, 0.006756757, 0.004504505, 0.756756757, 0.207207207, 0.006756757, 0.009009009, 0.0, 0.049180328, 0.081967213, 0.016393443, 0.786885246, 0.049180328, 0.016393443, 0.05, 0.03, 0.04, 0.8, 0.04, 0.04, 0.0, 0.104166667, 0.0, 0.020833333, 0.75, 0.020833333, 0.0, 0.104166667, 0.011286682, 0.155756208, 0.002257336, 0.803611738, 0.002257336, 0.011286682, 0.013544018, 0.16, 0.16, 0.04, 0.12, 0.2, 0.16, 0.16, 0.008695652, 0.007246377, 0.005797101, 0.756521739, 0.208695652, 0.004347826, 0.008695652, 0.023529412, 0.011764706, 0.070588235, 0.047058824, 0.058823529, 0.011764706, 0.776470588, 0.0, 0.8, 0.066666667, 0.033333333, 0.066666667, 0.0, 0.033333333, 0.046153846, 0.015384615, 0.076923077, 0.0, 0.015384615, 0.061538462, 0.784615385, 0.011111111, 0.16, 0.006666667, 0.004444444, 0.808888889, 0.006666667, 0.002222222, 0.011235955, 0.056179775, 0.06741573, 0.04494382, 0.775280899, 0.0, 0.04494382, 0.0, 0.157598499, 0.011257036, 0.803001876, 0.009380863, 0.009380863, 0.009380863, 0.0, 0.052631579, 0.035087719, 0.0, 0.842105263, 0.035087719, 0.035087719, 0.018018018, 0.045045045, 0.018018018, 0.783783784, 0.054054054, 0.054054054, 0.027027027, 0.045454545, 0.136363636, 0.181818182, 0.136363636, 0.181818182, 0.181818182, 0.136363636, 0.0, 0.777777778, 0.037037037, 0.074074074, 0.037037037, 0.049382716, 0.024691358, 0.384615385, 0.076923077, 0.384615385, 0.153846154, 0.0, 0.0, 0.0, 0.014925373, 0.014925373, 0.059701493, 0.044776119, 0.059701493, 0.76119403, 0.044776119, 0.0, 0.75, 0.0, 0.003731343, 0.246268657, 0.0, 0.0, 0.039370079, 0.039370079, 0.0, 0.047244094, 0.818897638, 0.047244094, 0.007874016, 0.0, 0.76744186, 0.058139535, 0.058139535, 0.023255814, 0.069767442, 0.023255814, 1.17e-05, 1.17e-05, 3.9e-06, 7.79e-06, 0.999707848, 0.000249303, 7.79e-06, 0.051546392, 0.051546392, 0.010309278, 0.030927835, 0.030927835, 0.773195876, 0.051546392, 0.04, 0.0, 0.0, 0.8, 0.013333333, 0.08, 0.066666667, 0.043956044, 0.032967033, 0.010989011, 0.054945055, 0.791208791, 0.032967033, 0.032967033, 0.043478261, 0.043478261, 0.173913043, 0.130434783, 0.217391304, 0.173913043, 0.217391304, 0.029411765, 0.058823529, 0.75, 0.073529412, 0.0, 0.073529412, 0.014705882, 0.036363636, 0.036363636, 0.790909091, 0.027272727, 0.054545455, 0.054545455, 0.0, 0.096774194, 0.774193548, 0.0, 0.0, 0.032258065, 0.032258065, 0.064516129, 0.217391304, 0.217391304, 0.086956522, 0.217391304, 0.043478261, 0.043478261, 0.173913043, 0.0125, 0.075, 0.0, 0.075, 0.7875, 0.0375, 0.0125, 0.022900763, 0.030534351, 0.045801527, 0.015267176, 0.824427481, 0.030534351, 0.030534351, 0.0, 0.75, 0.245810056, 0.000837989, 0.000837989, 0.001117318, 0.001396648, 0.0, 0.109859155, 0.008450704, 0.005633803, 0.005633803, 0.109859155, 0.76056338, 0.002359418, 0.0, 0.194651986, 0.0, 0.001572945, 0.800629178, 0.000786473, 0.043956044, 0.043956044, 0.032967033, 0.043956044, 0.032967033, 0.758241758, 0.043956044, 0.011709602, 0.014051522, 0.014051522, 0.011709602, 0.007025761, 0.18969555, 0.75175644, 0.000371058, 0.016697588, 0.001113173, 0.001113173, 0.979591837, 0.0, 0.001113173, 0.003442341, 0.00172117, 0.15232358, 0.802065404, 0.038726334, 0.000860585, 0.000860585, 0.757575758, 0.060606061, 0.050505051, 0.01010101, 0.050505051, 0.060606061, 0.01010101, 0.025641026, 0.769230769, 0.0, 0.051282051, 0.051282051, 0.051282051, 0.051282051, 0.0, 0.0667, 0.0444, 0.0, 0.8, 0.044444444, 0.0444, 0.0, 0.333333333, 0.111111111, 0.166666667, 0.166666667, 0.111111111, 0.111111111, 0.208333333, 0.25, 0.083333333, 0.083333333, 0.083333333, 0.125, 0.166666667, 0.012698413, 0.0, 0.0, 0.00952381, 0.0, 0.977777778, 0.0, 0.00982801, 0.004914005, 0.191646192, 0.004914005, 0.014742015, 0.014742015, 0.759213759, 0.001963351, 0.000327225, 0.000327225, 0.979057592, 0.001636126, 0.016688482, 0.0, 0.002318034, 0.002318034, 0.002318034, 0.038942976, 0.202132592, 0.000927214, 0.751043115});
    if (DSL_OKAY != res7)
    {
        std::cerr << "Failed to set definition for Ps.\n";
        return res7;
    }

    int F = CreateEquationNode(net, "F", "event frequency","F=Choose(E,Poisson(0.5),Poisson(2),Poisson(5),Poisson(10),Poisson(15),Poisson(25),Poisson(40))", 0, t, 100, 100);
    SetUniformIntervals(net, F, discIntervals);
    net.UpdateBeliefs();


    std::vector<std::string> tNodeIds = CreateTn(net, "S", "T", 0, 20, 125, 300, 25, t, t/discIntervals, "=Choose(E,Exponential(0.5),Exponential(1),Exponential(1.5),Exponential(2),Exponential(2.5),Exponential(3.5),Exponential(5))");
    std::vector<int> fHandles = CreateFNodes(net, "F", F, tNodeIds, 500, 300, 25, 0, 1300*t/discIntervals, t/discIntervals);

    net.UpdateBeliefs();
    return net.WriteFile("D:/model/operational risk.xdsl");
}

static int CopyNode(DSL_network &net, int sourceNodeHandle, const std::string &newNodeId, int start, int end) {
    int num_intervals = 25;  
    double step = static_cast<double>(end - start) / num_intervals; 

    int newNodeHandle = net.AddNode(DSL_CPT, newNodeId.c_str());
    if (newNodeHandle < 0) {
        std::cerr << "Failed to create new node: " << newNodeId << std::endl;
        return -1;
    }

    DSL_node *sourceNode = net.GetNode(sourceNodeHandle);
    DSL_node *newNode = net.GetNode(newNodeHandle);

    newNode->SetName(newNodeId.c_str());
    newNode->Def()->SetNumberOfOutcomes(*sourceNode->Def()->GetOutcomeIds());


    std::vector<double> values;
    for (int i = 0; i <= num_intervals; ++i) {
        values.push_back(start + i * step);
    }

    auto discDef = net.GetNode(newNodeHandle)->Def<DSL_discDef>(); 
    discDef->SetIntervals(values, true);

    const DSL_intArray &parents = sourceNode->Def()->GetParents();
    for (int i = 0; i < parents.GetSize(); ++i) {
        net.AddArc(parents[i], newNodeHandle);
    }


    const DSL_Dmatrix *sourceCPT = sourceNode->Def()->GetMatrix();
    newNode->Def()->SetDefinition(*sourceCPT);

    PrintNodeInfo(net, newNodeHandle);

    return newNodeHandle;
}

static std::vector<std::string> CreateTn(DSL_network &net, const std::string &baseNameS, const std::string &baseNameT,
                                                 double loBound, double hiBound, int xPos, int yPos, int discIntervals, int numSNodes,int numNodes,const std::string &equation) {
    std::vector<std::string> tNodeIds; 
    int previousHandle = -1;   
    MyProgress progress;      
    int tHandle = -1;
    std::string tid;
    double lo, hi;
    int xPos1 = xPos-125;
    int yPos1 = yPos-100;
    int nodeCount = 0;  
    const int maxNodesPerColumn = 10; 

    int sHandles[2]; 
    for (int i = 0; i < 2; ++i) {
        std::string sNodeId = baseNameS + std::to_string(i);
        std::string equationS = sNodeId + equation;
        sHandles[i] = CreateEquationNode(net, sNodeId.c_str(), sNodeId.c_str(), equationS.c_str(), loBound, hiBound, xPos1, yPos1);
        if (sHandles[i] == -1) {
            std::cerr << "create " << sNodeId << " fail" << std::endl;
            return {}; 
        }
        SetUniformIntervals(net, sHandles[i], discIntervals);
        net.UpdateBeliefs();

    }


    std::string t1NodeId = baseNameT+"2";
    std::string equationT1 = t1NodeId + " = " + net.GetNode(sHandles[0])->GetId() + " + " + net.GetNode(sHandles[1])->GetId();
    int t1Handle = CreateEquationNode(net, t1NodeId.c_str(), t1NodeId.c_str(), equationT1.c_str(), loBound, hiBound + 2, xPos, yPos);
    if (t1Handle == -1) {
        std::cerr << "fail" << std::endl;
        return {}; 
    }
    SetUniformIntervals(net, t1Handle, discIntervals);
    net.UpdateBeliefs();

    std::vector<int> initialHandles = {sHandles[0], sHandles[1], t1Handle};

    for (int handle : initialHandles) {
        DSL_node* node = net.GetNode(handle);
        if (node) {
            int result = node->ChangeType(DSL_CPT);
            if (result == DSL_OKAY) {
                std::cout << "node " << node->GetId() << " success" << std::endl;
            } else {
                std::cerr << "node " << node->GetId() << " fail" << result << std::endl;
            }
        }
    }
    net.UpdateBeliefs();

    // previousHandle = t1Handle;
    // if(numNodes == 2){
    //     std::string copyId = baseNameT+"copy2";
    //     std::string equationcopyT1 = copyId + " = " + net.GetNode(sHandles[0])->GetId() + " + " + net.GetNode(sHandles[1])->GetId();
    //     int CopyHandle = CreateEquationNode(net, copyId.c_str(), copyId.c_str(), equationcopyT1.c_str(), loBound, hiBound + 2, 100, 0);
    //     SetUniformIntervals(net, CopyHandle, discIntervals);
    //     net.UpdateBeliefs();
    //     previousHandle = CopyHandle;
    //     tNodeIds.push_back(t1NodeId);
    // }
    net.MarginalizeNode(sHandles[0], &progress);
    net.MarginalizeNode(sHandles[1], &progress);

    if(numNodes == 2){
        std::string copyId = "T2copy";
        int CopyHandle = CopyNode(net, t1Handle, copyId, loBound, hiBound + 2);
        previousHandle = CopyHandle;
        tNodeIds.push_back(t1NodeId);
    }

    nodeCount++; 

    for (int i = 3; i <= numSNodes; ++i) {
        std::cout << "start " << i << " loop" << std::endl;
        if(i % numNodes == 0 && i != numNodes){
            yPos += 50;
            nodeCount++;  
        }


        std::string sNodeId = baseNameS + std::to_string(i);
        std::string equationS = sNodeId + equation;
        int sHandle = CreateEquationNode(net, sNodeId.c_str(), sNodeId.c_str(), equationS.c_str(), loBound, hiBound, xPos1, yPos1);
        if (sHandle == -1) {
            std::cout << "fail " << sNodeId << std::endl;
            continue; 
        }
        SetUniformIntervals(net, sHandle, discIntervals);
        net.UpdateBeliefs();

  
        std::string tNodeId = baseNameT + std::to_string(i);
        std::string equationT = tNodeId + " = " + net.GetNode(sHandle)->GetId() + " + " + net.GetNode(previousHandle)->GetId();
        int tHandle = CreateEquationNode(net, tNodeId.c_str(), tNodeId.c_str(), equationT.c_str(), loBound, hiBound + 2*(i-1), xPos, yPos);
        if (tHandle == -1) {
            std::cout << "fail " << tNodeId << std::endl;
            continue; 
        }
        SetUniformIntervals(net, tHandle, discIntervals);
        net.UpdateBeliefs();


        std::vector<int> currentHandles = {sHandle, tHandle};
        for (int handle : currentHandles) {
            DSL_node* node = net.GetNode(handle);
            if (node) {
                int result = node->ChangeType(DSL_CPT);
                if (result == DSL_OKAY) {
                    std::cout << "node " << node->GetId() << " success" << std::endl;
                } else {
                    std::cerr << "node " << node->GetId() << " fail " << result << std::endl;
                }
            }
        }
        net.UpdateBeliefs();

   
        net.MarginalizeNode(sHandle, &progress);
        net.MarginalizeNode(previousHandle, &progress);
        previousHandle = tHandle;

        // if(i % numNodes == 0 & i != numSNodes){
        //     std::string copyId = baseNameT+"copy" + std::to_string(i);
        //     std::string equationcopyT = copyId + " = " + net.GetNode(sHandle)->GetId() + " + " + net.GetNode(previousHandle)->GetId();
        //     int CopyHandle = CreateEquationNode(net, copyId.c_str(), copyId.c_str(), equationcopyT.c_str(), loBound, hiBound + 2*(i-1), 100, 0+i-2);
        //     SetUniformIntervals(net, CopyHandle, discIntervals);
        //     net.UpdateBeliefs();
        //     previousHandle = CopyHandle;
        //     tNodeIds.push_back(tNodeId);
        // }else{
        //     previousHandle = tHandle;
        // }


        if(i % numNodes == 0 & i != numSNodes){
            std::string copyId = "Tcopy" + std::to_string(i);
            int CopyHandle = CopyNode(net, tHandle, copyId, loBound, hiBound + 2*(i-1));
            previousHandle = CopyHandle;
            tNodeIds.push_back(tNodeId);
        }

        if(i == numSNodes){
            tid = net.GetNode(tHandle)->GetId();
            lo = loBound;
            hi = hiBound + 2*(i-1);
            tNodeIds.push_back(tid);
        }

        if (nodeCount >= maxNodesPerColumn) {
            yPos = 300;
            xPos += 100;  
            nodeCount = 0;  
        }

    }
    return tNodeIds; 
}


static std::vector<int> CreateFNodes(DSL_network &net, const std::string &baseName,
                                     int fHandle, const std::vector<std::string> &tNodeIds,
                                     int xPos, int yPos, int discIntervals,
                                     double loBound, double hiBound, int s) { 
    std::vector<int> fHandles;
    int numTNodes = static_cast<int>(tNodeIds.size());
    int nodeCount = 0; 
    const int maxNodesPerColumn = 10;  

    std::string f0Id = baseName + "0";
    std::string f0Equation = f0Id + " = If(And(F>=0,F<"+std::to_string(s)+"), " + tNodeIds[0] + ", " + tNodeIds[1] + ")";
    int f0Handle = CreateEquationNode(net, f0Id.c_str(), f0Id.c_str(), f0Equation.c_str(), loBound, hiBound+s*300, xPos, yPos);
    if (f0Handle != -1) {
        SetUniformIntervals(net, f0Handle, discIntervals);
        net.UpdateBeliefs();
        fHandles.push_back(f0Handle);
    }

    yPos += 50;
    nodeCount++; 
    for (int i = 1; i < numTNodes-1; ++i) {
        std::string fiId = baseName + std::to_string(i);
        std::vector<std::string> conditions;
        for (int j = 0; j <= i; ++j) {
            conditions.push_back("F = " + std::to_string(j));
        }
        std::string condition = "Or(" + join(conditions, ", ") + ")";
        std::string equation = fiId + " = If(And(F>=0,F<"+ std::to_string(s*(i+1)) +"),"+ net.GetNode(fHandles[i - 1])->GetId() + ", " + tNodeIds[i + 1] + ")";
        int fiHandle = CreateEquationNode(net, fiId.c_str(), fiId.c_str(), equation.c_str(), loBound, hiBound+s*300*(i+1)*2.3, xPos, yPos);
        if (fiHandle != -1) {
            SetUniformIntervals(net, fiHandle, discIntervals);
            net.UpdateBeliefs();
            fHandles.push_back(fiHandle);
        }
        yPos += 50;
        nodeCount++;  

        if (nodeCount >= maxNodesPerColumn) {
            yPos = 300;
            xPos += 100;  
            nodeCount = 0; 
        }
        
        
    }

    return fHandles;
}


std::string join(const std::vector<std::string>& elements, const std::string& separator) {
    std::string result;
    for (size_t i = 0; i < elements.size(); ++i) {
        if (i > 0) {
            result += separator;
        }
        result += elements[i];
    }
    return result;
}

static void PrintPosteriors(DSL_network &net, int handle)
{
    DSL_node *node = net.GetNode(handle);
    const char* nodeId = node->GetId();
    const DSL_nodeVal* val = node->Val();
    if (val->IsEvidence())
    {
        printf("%s has evidence set (%s)\n", 
            nodeId, val->GetEvidenceId());
    }
    else
    {
        const DSL_idArray& outcomeIds = *node->Def()->GetOutcomeIds();
        const DSL_Dmatrix& posteriors = *val->GetMatrix();
        for (int i = 0; i < posteriors.GetSize(); i++)
        {
            printf("P(%s=%s)=%g\n", nodeId, outcomeIds[i], posteriors[i]);
        }
    }
}

static void PrintAllPosteriors(DSL_network &net)
{
    for (int h = net.GetFirstNode(); h >= 0; h = net.GetNextNode(h))
    {
        PrintPosteriors(net, h);
    }
}

static int ChangeEvidenceAndUpdate(
    DSL_network &net, const char *nodeId, const char *outcomeId)
{
    DSL_node* node = net.GetNode(nodeId);
    if (NULL == node)
    {
        return DSL_OUT_OF_RANGE;
    }

    int res;
    if (NULL != outcomeId)
    {
        res = node->Val()->SetEvidence(outcomeId);
    }
    else
    {
        res = node->Val()->ClearEvidence();
    }
    if (DSL_OKAY != res)
    {
        return res;
    }

    res = net.UpdateBeliefs();
    if (DSL_OKAY != res)
    {
        return res;
    }
    PrintAllPosteriors(net);
    return DSL_OKAY;
}

static int CreateCptNode(DSL_network &net, const char *id, const char *name, std::initializer_list<const char *> outcomes, int xPos, int yPos)
{
    int handle = net.AddNode(DSL_CPT, id);
    DSL_node *node = net.GetNode(handle);
    node->SetName(name);
    node->Def()->SetNumberOfOutcomes(outcomes);
    DSL_rectangle &position = node->Info().Screen().position;
    position.center_X = xPos;
    position.center_Y = yPos;
    position.width = 85;
    position.height = 55;
    return handle;
}

static int CreateEquationNode(
	DSL_network &net, const char *id, const char *name,
    const char *equation, double loBound, double hiBound,
    int xPos, int yPos)
{
    int handle = net.AddNode(DSL_EQUATION, id);
    DSL_node *node = net.GetNode(handle);
    node->SetName(name);
    auto eq = node->Def<DSL_equation>();
    eq->SetEquation(equation);
    eq->SetBounds(loBound, hiBound);
    DSL_rectangle &position = node->Info().Screen().position;
    position.center_X = xPos;
    position.center_Y = yPos;
    position.width = 85;
    position.height = 55;
    return handle;
}

static void ShowStats(DSL_network& net, int nodeHandle)
{
    DSL_node* node = net.GetNode(nodeHandle);
    const char* nodeId = node->GetId();

    auto eqVal = node->Val<DSL_equationEvaluation>();
    if (eqVal->IsEvidence())
    {
        double v;
        eqVal->GetEvidence(v);
        printf("%s has evidence set (%g)\n", nodeId, v);
        return;
    }

    const DSL_Dmatrix& discBeliefs = eqVal->GetDiscBeliefs();
    if (discBeliefs.IsEmpty())
    {
        double mean, stddev, vmin, vmax;
        eqVal->GetStats(mean, stddev, vmin, vmax);
        printf("%s: mean=%g stddev=%g min=%g max=%g\n",
            nodeId, mean, stddev, vmin, vmax);
    }
    else
    {
        auto eqDef = node->Def<DSL_equation>();
        const DSL_equation::IntervalVector& iv = eqDef->GetDiscIntervals();
        printf("%s is discretized.\n", nodeId);
        double loBound, hiBound;
        eqDef->GetBounds(loBound, hiBound);
        double lo = loBound;
        for (int i = 0; i < discBeliefs.GetSize(); i++)
        {
            double hi = iv[i].second;
            printf("\tP(%s in %g..%g)=%g\n", nodeId, lo, hi, discBeliefs[i]);
            lo = hi;
        }
    }
}

static void UpdateAndShowStats(DSL_network &net)
{
    net.UpdateBeliefs();
    for (int h = net.GetFirstNode(); h >= 0; h = net.GetNextNode(h))
    {
        if (net.GetNode(h)->Def()->GetType() == DSL_EQUATION)
        { 
           ShowStats(net, h);
        }
    }
}

static void SetUniformIntervals(DSL_network &net, int nodeHandle, int count)
{
    auto eq = net.GetNode(nodeHandle)->Def<DSL_equation>();
    double lo, hi;
    eq->GetBounds(lo, hi);
    DSL_equation::IntervalVector iv(count);
    for (int i = 0; i < count; i++)
    {
        iv[i].second = lo + (i + 1) * (hi - lo) / count;
    }
    eq->SetDiscIntervals(iv);
}

static void PrintMatrix(
    DSL_network &net, const DSL_Dmatrix &mtx, 
    const DSL_idArray &outcomes, const DSL_intArray &parents)
{
    int dimCount = mtx.GetNumberOfDimensions();
    DSL_intArray coords(dimCount);
    coords.FillWith(0);

    // elemIdx and coords will be moving in sync
    for (int elemIdx = 0; elemIdx < mtx.GetSize(); elemIdx++)
    {
        const char *outcome = outcomes[coords[dimCount - 1]];
        printf("    P(%s", outcome);

        if (dimCount > 1)
        {
            printf(" | ");
            for (int parentIdx = 0; parentIdx < dimCount - 1; parentIdx++)
            {
                if (parentIdx > 0) printf(",");
                DSL_node *parentNode = net.GetNode(parents[parentIdx]);
                const DSL_idArray &parentOutcomes = 
                    *parentNode->Def()->GetOutcomeIds();
                printf("%s=%s", 
                    parentNode->GetId(), parentOutcomes[coords[parentIdx]]);
            }
        }

        double prob = mtx[elemIdx];
        printf(")=%g\n", prob);

        mtx.NextCoordinates(coords);
    }
}

static void PrintNodeInfo(DSL_network &net, int nodeHandle)
{
    DSL_node *node = net.GetNode(nodeHandle);
    printf("Node: %s\n", node->GetName());

    printf("  Outcomes:");
    const DSL_idArray &outcomes = *node->Def()->GetOutcomeIds();
    for (const char* oid : outcomes)
    {
        printf(" %s", oid);
    }
    printf("\n");

    const DSL_intArray &parents = net.GetParents(nodeHandle);
    if (!parents.IsEmpty())
    {
        printf("  Parents:");
        for (int p: parents)
        {
            printf(" %s", net.GetNode(p)->GetId());
        }
        printf("\n");
    }

    const DSL_intArray &children = net.GetChildren(nodeHandle);
    if (!children.IsEmpty())
    {
        printf("  Children:");
        for (int c: children)
        {
            printf(" %s", net.GetNode(c)->GetId());
        }
        printf("\n");
    }

    const DSL_nodeDef *def = node->Def();
    int defType = def->GetType();
    printf("  Definition type: %s\n", def->GetTypeName());
    if (DSL_CPT == defType || DSL_TRUTHTABLE == defType)
    {
        const DSL_Dmatrix &cpt = *def->GetMatrix();
        PrintMatrix(net, cpt, outcomes, parents);
    }
}

