#ifndef CDECL
#ifdef _WIN32
#define CDECL __cdecl
#else
#define CDECL
#endif
#endif
#define SMILE_NO_V1_COMPATIBILITY
#include <vector>
#include <string>
#include <iostream>
#include <smile.h>
#include <node.h>
#include <cstdio>
#include <discdef.h>
#include <nodedef.h>
#include <nodeval.h>
#include <network.h>
#include <iomanip>
#include "progress.h"
#include "smile_license.h"

struct TsTriangulatorStats
{
	unsigned nodeCount;
	unsigned threshold;
	unsigned cliqueCount;
	unsigned totalCliqueSize;
	unsigned maxCliqueSize;
	unsigned maxCliqueWidth;
	unsigned totalSeparatorSize;
	unsigned maxSeparatorSize;
	unsigned maxSeparatorWidth;
	std::vector<unsigned> cliqueSizes;
};
extern void (CDECL* TsTriangulatorStatsFunc)(TsTriangulatorStats*);


class MyProgress : public DSL_progress {
public:
    virtual bool Tick(double percComplete, const char *msg) override {
        if (percComplete >= 0) {
            std::cout << "Progress: " << std::fixed << std::setprecision(2) << percComplete << "% completed.";
        } else {
            std::cout << "Progress: Unable to estimate completion percentage.";
        }

        if (msg) {
            std::cout << " Message: " << msg;
        }
        std::cout << std::endl;

        return true; 
    }
};

// Function declaration
static int CreateCptNode(DSL_network &net, const char *id, const char *name, std::initializer_list<const char *> outcomes, int xPos, int yPos);
static void ShowStats(DSL_network &net, int nodeHandle);
static void UpdateAndShowStats(DSL_network &net);
static int CreateEquationNode(
	DSL_network &net, const char *id, const char *name,
    const char *equation, double loBound, double hiBound,
    int xPos, int yPos);
static void PrintPosteriors(DSL_network &net, int handle);
static void PrintAllPosteriors(DSL_network &net);
static void SetUniformIntervals(DSL_network &net, int nodeHandle, int count);
static int ChangeEvidenceAndUpdate(
    DSL_network &net, const char *nodeId, const char *outcomeId);
static void PrintMatrix(
    DSL_network &net, const DSL_Dmatrix &mtx, 
    const DSL_idArray &outcomes, const DSL_intArray &parents);
static void PrintNodeInfo(DSL_network &net, int nodeHandle);
static int CopyNode(DSL_network &net, int sourceNodeHandle, const std::string &newNodeId, int start, int end);
static std::vector<std::string> CreateTn(DSL_network &net, const std::string &baseNameS, const std::string &baseNameT, 
                                                 double loBound, double hiBound, int xPos, int yPos, int discIntervals, int numSNodes,int numNodes,const std::string &equation);
static std::vector<int> CreateFNodes(DSL_network &net, const std::string &baseName,
                                     int fHandle, const std::vector<std::string> &tNodeIds,
                                     int xPos, int yPos, int discIntervals,
                                     double loBound, double hiBound, int s);
std::string join(const std::vector<std::string>& elements, const std::string& separator);
void CheckIfNodeIsDiscretized(DSL_network &net, int nodeHandle) {
    DSL_node *node = net.GetNode(nodeHandle);
    if (!node) {
        std::cerr << "The node is invalid or does not exist." << std::endl;
        return;
    }

    // Obtain the equation evaluation object of the node
    auto eqVal = node->Val<DSL_equationEvaluation>();
    
    // Check if it has been discretized
    if (eqVal->IsDiscretized()) {
        std::cout << "node " << node->GetId() << " has been discretized" << std::endl;
    } else {
        std::cout << "node " << node->GetId() << " has not been discretized" << std::endl;
    }
}

// void CDECL MyTriangulatorStatsFunc(TsTriangulatorStats* stats)
// {
//     printf("maxCliqueSize=%d, totalCliqueSize=%d, maxCliqueWidth=%d, nodeCount=%d, cliqueCount=%d, totalSeparatorSize=%d\n", stats->maxCliqueSize, stats->totalCliqueSize, stats->maxCliqueWidth, stats->nodeCount, stats->cliqueCount, stats->totalSeparatorSize);
//     fflush(stdout);  
// }


int main()
{
    DSL_errorH().RedirectToFile(stdout);
    DSL_network net;
    // Number of discrete frequencies
    int discIntervals = 20; 
    // Upper frequency limit
    int t = 100;
    MyProgress progress;
    int io = 0;
    int resultCode = net.SetNumberOfSamples(10000);
    if (resultCode != DSL_OKAY) {
        std::cerr << "Failed to set the number of samples. Error code: " << resultCode << std::endl;
    }
    net.SetNumberOfDiscretizationSamples(1000);

    // define C
    int CHandle = CreateCptNode(net, "C", "C", {"C1", "C2"}, 500, -200);
    // cpt
    int res4 = net.GetNode(CHandle)->Def()->SetDefinition({
        0.3,
        0.7
    });
    if (DSL_OKAY != res4)
    {
        std::cerr << "Failed to set definition.\n";
        return res4;
    }


    // define F
    int F = CreateEquationNode(net, "F", "Frequency","F=Choose(C,Normal(70,10),Normal(30,10))", 0, t, 700, 200);
    SetUniformIntervals(net, F, discIntervals);
    net.UpdateBeliefs();

    std::vector<std::string> tNodeIds = CreateTn(net, "S", "T", 0, 2800, 125, 300, 25, t, t/discIntervals, "=Choose(C,Normal(620,200),Normal(1600,300))");
    std::vector<int> fHandles = CreateFNodes(net, "F", F, tNodeIds, 500, 300, 25, 0, 19500, t/discIntervals);

    net.UpdateBeliefs();

    return net.WriteFile("D:/model/single.xdsl");
}

// Copy nodes and maintain their attributes and relationships
static int CopyNode(DSL_network &net, int sourceNodeHandle, const std::string &newNodeId, int start, int end) {
    int num_intervals = 25;  // bins
    double step = static_cast<double>(end - start) / num_intervals;  // step

    // Create a new node and obtain its handle
    int newNodeHandle = net.AddNode(DSL_CPT, newNodeId.c_str());
    if (newNodeHandle < 0) {
        std::cerr << "Failed to create new node: " << newNodeId << std::endl;
        return -1;
    }

    DSL_node *sourceNode = net.GetNode(sourceNodeHandle);
    DSL_node *newNode = net.GetNode(newNodeHandle);

    // Set the name and output of the new node
    newNode->SetName(newNodeId.c_str());
    newNode->Def()->SetNumberOfOutcomes(*sourceNode->Def()->GetOutcomeIds());


    std::vector<double> values;
    for (int i = 0; i <= num_intervals; ++i) {
        values.push_back(start + i * step);
    }

    auto discDef = net.GetNode(newNodeHandle)->Def<DSL_discDef>(); 
    discDef->SetIntervals(values, true);

    // Copy the parent node of the source node and set the same parent node for the new node
    const DSL_intArray &parents = sourceNode->Def()->GetParents();
    for (int i = 0; i < parents.GetSize(); ++i) {
        net.AddArc(parents[i], newNodeHandle);
    }


    // Definition of Copy Conditional Probability Table (CPT)
    const DSL_Dmatrix *sourceCPT = sourceNode->Def()->GetMatrix();
    newNode->Def()->SetDefinition(*sourceCPT);


    // Print new node information
    PrintNodeInfo(net, newNodeHandle);

    return newNodeHandle;
}


// Create and aggregate T nodes, while retaining and redefining the CPT of T nodes
static std::vector<std::string> CreateTn(DSL_network &net, const std::string &baseNameS, const std::string &baseNameT,
                                                 double loBound, double hiBound, int xPos, int yPos, int discIntervals, int numSNodes,int numNodes,const std::string &equation) {
    std::vector<std::string> tNodeIds; 
    int previousHandle = -1;  
    MyProgress progress;    
    int tHandle = -1;
    std::string tid;
    double lo, hi;
    int xPos1 = xPos-125;
    int yPos1 = yPos-100;
    int nodeCount = 0;  
    const int maxNodesPerColumn = 10;  

    //  Create initial S0 and S1 nodes
    int sHandles[2]; // Handle for storing S0 and S1
    for (int i = 0; i < 2; ++i) {
        std::string sNodeId = baseNameS + std::to_string(i);
        std::string equationS = sNodeId + equation;
        sHandles[i] = CreateEquationNode(net, sNodeId.c_str(), sNodeId.c_str(), equationS.c_str(), loBound, hiBound, xPos1, yPos1);
        if (sHandles[i] == -1) {
            std::cerr << "Create " << sNodeId << " Node failed " << std::endl;
            return {}; 
        }
        SetUniformIntervals(net, sHandles[i], discIntervals);
        net.UpdateBeliefs();

    }

    // Create the first T node (T1) to connect S0 and S1
    std::string t1NodeId = baseNameT+"2";
    std::string equationT1 = t1NodeId + " = " + net.GetNode(sHandles[0])->GetId() + " + " + net.GetNode(sHandles[1])->GetId();
    int t1Handle = CreateEquationNode(net, t1NodeId.c_str(), t1NodeId.c_str(), equationT1.c_str(), loBound, hiBound + 1900, xPos, yPos);
    if (t1Handle == -1) {
        std::cerr << "Failed to create T2 node" << std::endl;
        return {}; 
    }
    SetUniformIntervals(net, t1Handle, discIntervals);
    net.UpdateBeliefs();

    std::vector<int> initialHandles = {sHandles[0], sHandles[1], t1Handle};
    // Discretize nodes S0, S1, and T1 (convert to CPT type)
    for (int handle : initialHandles) {
        DSL_node* node = net.GetNode(handle);
        if (node) {
            int result = node->ChangeType(DSL_CPT);
            if (result == DSL_OKAY) {
                std::cout << "Node " << node->GetId() << "Type successfully changed to CPT" << std::endl;
            } else {
                std::cerr << "Node " << node->GetId() << " Type change failed, error code: " << result << std::endl;
            }
        }
    }
    net.UpdateBeliefs();

    previousHandle = t1Handle;
    // // If it is a continuous node
    // if(numNodes == 2){
    //     std::string copyId = baseNameT+"copy2";
    //     std::string equationcopyT1 = copyId + " = " + net.GetNode(sHandles[0])->GetId() + " + " + net.GetNode(sHandles[1])->GetId();
    //     int CopyHandle = CreateEquationNode(net, copyId.c_str(), copyId.c_str(), equationcopyT1.c_str(), loBound, hiBound + 1900, 100, 0);
    //     SetUniformIntervals(net, CopyHandle, discIntervals);
    //     net.UpdateBeliefs();
    //     previousHandle = CopyHandle;
    //     tNodeIds.push_back(t1NodeId);
    // }
    net.MarginalizeNode(sHandles[0], &progress);
    net.MarginalizeNode(sHandles[1], &progress);

    // If it is a discrete node
    if(numNodes == 2){
        std::string copyId = "T2copy";
        int CopyHandle = CopyNode(net, t1Handle, copyId, loBound, hiBound + 1900);
        previousHandle = CopyHandle;
        tNodeIds.push_back(t1NodeId);
    }

    nodeCount++; 

    // Starting from T2, create subsequent nodes
    for (int i = 3; i <= numSNodes; ++i) {
        std::cout << "Start the" << i << " th loop" << std::endl;
        if(i % numNodes == 0 && i != numNodes){
            yPos += 50;
            nodeCount++;  
        }

        // Create Si nodes and set their equations
        std::string sNodeId = baseNameS + std::to_string(i);
        std::string equationS = sNodeId + equation;
        int sHandle = CreateEquationNode(net, sNodeId.c_str(), sNodeId.c_str(), equationS.c_str(), loBound, hiBound, xPos1, yPos1);
        if (sHandle == -1) {
            std::cout << "Failed to create Si node: " << sNodeId << std::endl;
            continue; 
        }
        SetUniformIntervals(net, sHandle, discIntervals);
        net.UpdateBeliefs();

        // Create Ti nodes and set their equations
        std::string tNodeId = baseNameT + std::to_string(i);
        std::string equationT = tNodeId + " = " + net.GetNode(sHandle)->GetId() + " + " + net.GetNode(previousHandle)->GetId();
        int tHandle = CreateEquationNode(net, tNodeId.c_str(), tNodeId.c_str(), equationT.c_str(), loBound, hiBound + 1900*(i-1), xPos, yPos);
        if (tHandle == -1) {
            std::cout << "Failed to create Ti node: " << tNodeId << std::endl;
            continue; 
        }
        SetUniformIntervals(net, tHandle, discIntervals);
        net.UpdateBeliefs();

        // Convert nodes to CPT type
        std::vector<int> currentHandles = {sHandle, tHandle};
        for (int handle : currentHandles) {
            DSL_node* node = net.GetNode(handle);
            if (node) {
                int result = node->ChangeType(DSL_CPT);
                if (result == DSL_OKAY) {
                    std::cout << "Node " << node->GetId() << "Type successfully changed to CPT" << std::endl;
                } else {
                    std::cerr << "Node " << node->GetId() << " Type change failed, error code: " << result << std::endl;
                }
            }
        }
        net.UpdateBeliefs();
   
        net.MarginalizeNode(sHandle, &progress);
        net.MarginalizeNode(previousHandle, &progress);
        previousHandle = tHandle;

        // // If it is a continuous node
        // if(i % numNodes == 0 & i != numSNodes){
        //     std::string copyId = baseNameT+"copy" + std::to_string(i);
        //     std::string equationcopyT = copyId + " = " + net.GetNode(sHandle)->GetId() + " + " + net.GetNode(previousHandle)->GetId();
        //     int CopyHandle = CreateEquationNode(net, copyId.c_str(), copyId.c_str(), equationcopyT.c_str(), loBound, hiBound + 1900*(i-1), 100, 0+i-2);
        //     SetUniformIntervals(net, CopyHandle, discIntervals);
        //     net.UpdateBeliefs();
        //     previousHandle = CopyHandle;
        //     tNodeIds.push_back(tNodeId);
        // }else{
        //     previousHandle = tHandle;
        // }

        // If it is a discrete node
        if(i % numNodes == 0 & i != numSNodes){
            // Copy T1 node for subsequent calculations
            std::string copyId = "Tcopy" + std::to_string(i);
            int CopyHandle = CopyNode(net, tHandle, copyId, loBound, hiBound + 1900*(i-1));
            previousHandle = CopyHandle;
            tNodeIds.push_back(tNodeId);
        }

        if(i == numSNodes){
            tid = net.GetNode(tHandle)->GetId();
            lo = loBound;
            hi = hiBound + 1900*(i-1);
            tNodeIds.push_back(tid);
        }

        // Check if it is necessary to switch trains
        if (nodeCount >= maxNodesPerColumn) {
            yPos = 300;
            xPos += 100;  
            nodeCount = 0;  
        }

    }
    return tNodeIds; 
}


// Create and configure functions for Fi nodes
static std::vector<int> CreateFNodes(DSL_network &net, const std::string &baseName,
                                     int fHandle, const std::vector<std::string> &tNodeIds,
                                     int xPos, int yPos, int discIntervals,
                                     double loBound, double hiBound, int s) {  // 添加了两个参数
    std::vector<int> fHandles;
    int numTNodes = static_cast<int>(tNodeIds.size());
    int nodeCount = 0;  // Counter, used to track the number of nodes in the current column
    const int maxNodesPerColumn = 10;  // Maximum number of nodes generated per column

    // 创建 F0 节点
    std::string f0Id = baseName + "0";
    std::string f0Equation = f0Id + " = If(And(F>=0,F<"+std::to_string(s)+"), " + tNodeIds[0] + ", " + tNodeIds[1] + ")";
    int f0Handle = CreateEquationNode(net, f0Id.c_str(), f0Id.c_str(), f0Equation.c_str(), loBound, hiBound, xPos, yPos);
    if (f0Handle != -1) {
        SetUniformIntervals(net, f0Handle, discIntervals);
        net.UpdateBeliefs();
        fHandles.push_back(f0Handle);
    }

    yPos += 50;
    nodeCount++;  
    // Create subsequent Fi nodes
    for (int i = 1; i < numTNodes-1; ++i) {
        std::string fiId = baseName + std::to_string(i);
        std::vector<std::string> conditions;
        for (int j = 0; j <= i; ++j) {
            conditions.push_back("F = " + std::to_string(j));
        }
        std::string condition = "Or(" + join(conditions, ", ") + ")";
        std::string equation = fiId + " = If(And(F>=0,F<"+ std::to_string(s*(i+1)) +"),"+ net.GetNode(fHandles[i - 1])->GetId() + ", " + tNodeIds[i + 1] + ")";
        int fiHandle = CreateEquationNode(net, fiId.c_str(), fiId.c_str(), equation.c_str(), loBound, hiBound+8000*i, xPos, yPos);
        if (fiHandle != -1) {
            SetUniformIntervals(net, fiHandle, discIntervals);
            net.UpdateBeliefs();
            fHandles.push_back(fiHandle);
        }
        yPos += 50;
        nodeCount++; 

        if (nodeCount >= maxNodesPerColumn) {
            yPos = 300;
            xPos += 100; 
            nodeCount = 0;  
        }
        
        
    }

    return fHandles;
}


// Auxiliary function: concatenate strings in a vector with specific separators
std::string join(const std::vector<std::string>& elements, const std::string& separator) {
    std::string result;
    for (size_t i = 0; i < elements.size(); ++i) {
        if (i > 0) {
            result += separator;
        }
        result += elements[i];
    }
    return result;
}

static void PrintPosteriors(DSL_network &net, int handle)
{
    DSL_node *node = net.GetNode(handle);
    const char* nodeId = node->GetId();
    const DSL_nodeVal* val = node->Val();
    if (val->IsEvidence())
    {
        printf("%s has evidence set (%s)\n", 
            nodeId, val->GetEvidenceId());
    }
    else
    {
        const DSL_idArray& outcomeIds = *node->Def()->GetOutcomeIds();
        const DSL_Dmatrix& posteriors = *val->GetMatrix();
        for (int i = 0; i < posteriors.GetSize(); i++)
        {
            printf("P(%s=%s)=%g\n", nodeId, outcomeIds[i], posteriors[i]);
        }
    }
}

static void PrintAllPosteriors(DSL_network &net)
{
    for (int h = net.GetFirstNode(); h >= 0; h = net.GetNextNode(h))
    {
        PrintPosteriors(net, h);
    }
}

static int ChangeEvidenceAndUpdate(
    DSL_network &net, const char *nodeId, const char *outcomeId)
{
    DSL_node* node = net.GetNode(nodeId);
    if (NULL == node)
    {
        return DSL_OUT_OF_RANGE;
    }

    int res;
    if (NULL != outcomeId)
    {
        res = node->Val()->SetEvidence(outcomeId);
    }
    else
    {
        res = node->Val()->ClearEvidence();
    }
    if (DSL_OKAY != res)
    {
        return res;
    }

    res = net.UpdateBeliefs();
    if (DSL_OKAY != res)
    {
        return res;
    }
    PrintAllPosteriors(net);
    return DSL_OKAY;
}

static int CreateCptNode(DSL_network &net, const char *id, const char *name, std::initializer_list<const char *> outcomes, int xPos, int yPos)
{
    int handle = net.AddNode(DSL_CPT, id);
    DSL_node *node = net.GetNode(handle);
    node->SetName(name);
    node->Def()->SetNumberOfOutcomes(outcomes);
    DSL_rectangle &position = node->Info().Screen().position;
    position.center_X = xPos;
    position.center_Y = yPos;
    position.width = 85;
    position.height = 55;
    return handle;
}

static int CreateEquationNode(
	DSL_network &net, const char *id, const char *name,
    const char *equation, double loBound, double hiBound,
    int xPos, int yPos)
{
    int handle = net.AddNode(DSL_EQUATION, id);
    DSL_node *node = net.GetNode(handle);
    node->SetName(name);
    auto eq = node->Def<DSL_equation>();
    eq->SetEquation(equation);
    eq->SetBounds(loBound, hiBound);
    DSL_rectangle &position = node->Info().Screen().position;
    position.center_X = xPos;
    position.center_Y = yPos;
    position.width = 85;
    position.height = 55;
    return handle;
}

static void ShowStats(DSL_network& net, int nodeHandle)
{
    DSL_node* node = net.GetNode(nodeHandle);
    const char* nodeId = node->GetId();

    auto eqVal = node->Val<DSL_equationEvaluation>();
    if (eqVal->IsEvidence())
    {
        double v;
        eqVal->GetEvidence(v);
        printf("%s has evidence set (%g)\n", nodeId, v);
        return;
    }

    const DSL_Dmatrix& discBeliefs = eqVal->GetDiscBeliefs();
    if (discBeliefs.IsEmpty())
    {
        double mean, stddev, vmin, vmax;
        eqVal->GetStats(mean, stddev, vmin, vmax);
        printf("%s: mean=%g stddev=%g min=%g max=%g\n",
            nodeId, mean, stddev, vmin, vmax);
    }
    else
    {
        auto eqDef = node->Def<DSL_equation>();
        const DSL_equation::IntervalVector& iv = eqDef->GetDiscIntervals();
        printf("%s is discretized.\n", nodeId);
        double loBound, hiBound;
        eqDef->GetBounds(loBound, hiBound);
        double lo = loBound;
        for (int i = 0; i < discBeliefs.GetSize(); i++)
        {
            double hi = iv[i].second;
            printf("\tP(%s in %g..%g)=%g\n", nodeId, lo, hi, discBeliefs[i]);
            lo = hi;
        }
    }
}

static void UpdateAndShowStats(DSL_network &net)
{
    net.UpdateBeliefs();
    for (int h = net.GetFirstNode(); h >= 0; h = net.GetNextNode(h))
    {
        if (net.GetNode(h)->Def()->GetType() == DSL_EQUATION)
        { 
           ShowStats(net, h);
        }
    }
}

static void SetUniformIntervals(DSL_network &net, int nodeHandle, int count)
{
    auto eq = net.GetNode(nodeHandle)->Def<DSL_equation>();
    double lo, hi;
    eq->GetBounds(lo, hi);
    DSL_equation::IntervalVector iv(count);
    for (int i = 0; i < count; i++)
    {
        iv[i].second = lo + (i + 1) * (hi - lo) / count;
    }
    eq->SetDiscIntervals(iv);
}

static void PrintMatrix(
    DSL_network &net, const DSL_Dmatrix &mtx, 
    const DSL_idArray &outcomes, const DSL_intArray &parents)
{
    int dimCount = mtx.GetNumberOfDimensions();
    DSL_intArray coords(dimCount);
    coords.FillWith(0);

    // elemIdx and coords will be moving in sync
    for (int elemIdx = 0; elemIdx < mtx.GetSize(); elemIdx++)
    {
        const char *outcome = outcomes[coords[dimCount - 1]];
        printf("    P(%s", outcome);

        if (dimCount > 1)
        {
            printf(" | ");
            for (int parentIdx = 0; parentIdx < dimCount - 1; parentIdx++)
            {
                if (parentIdx > 0) printf(",");
                DSL_node *parentNode = net.GetNode(parents[parentIdx]);
                const DSL_idArray &parentOutcomes = 
                    *parentNode->Def()->GetOutcomeIds();
                printf("%s=%s", 
                    parentNode->GetId(), parentOutcomes[coords[parentIdx]]);
            }
        }

        double prob = mtx[elemIdx];
        printf(")=%g\n", prob);

        mtx.NextCoordinates(coords);
    }
}

static void PrintNodeInfo(DSL_network &net, int nodeHandle)
{
    DSL_node *node = net.GetNode(nodeHandle);
    printf("Node: %s\n", node->GetName());

    printf("  Outcomes:");
    const DSL_idArray &outcomes = *node->Def()->GetOutcomeIds();
    for (const char* oid : outcomes)
    {
        printf(" %s", oid);
    }
    printf("\n");

    const DSL_intArray &parents = net.GetParents(nodeHandle);
    if (!parents.IsEmpty())
    {
        printf("  Parents:");
        for (int p: parents)
        {
            printf(" %s", net.GetNode(p)->GetId());
        }
        printf("\n");
    }

    const DSL_intArray &children = net.GetChildren(nodeHandle);
    if (!children.IsEmpty())
    {
        printf("  Children:");
        for (int c: children)
        {
            printf(" %s", net.GetNode(c)->GetId());
        }
        printf("\n");
    }

    const DSL_nodeDef *def = node->Def();
    int defType = def->GetType();
    printf("  Definition type: %s\n", def->GetTypeName());
    if (DSL_CPT == defType || DSL_TRUTHTABLE == defType)
    {
        const DSL_Dmatrix &cpt = *def->GetMatrix();
        PrintMatrix(net, cpt, outcomes, parents);
    }
}

